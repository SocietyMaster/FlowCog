package com.darmstadt.ecspride.ccs2013.data;

public class Password {
	private String password;
	
	public Password(String password){
		this.password = password;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
}
