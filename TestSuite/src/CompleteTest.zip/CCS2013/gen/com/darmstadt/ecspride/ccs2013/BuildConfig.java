/** Automatically generated file. DO NOT MODIFY */
package com.darmstadt.ecspride.ccs2013;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}