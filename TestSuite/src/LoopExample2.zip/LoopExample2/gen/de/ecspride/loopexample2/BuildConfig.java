/** Automatically generated file. DO NOT MODIFY */
package de.ecspride.loopexample2;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}