/** Automatically generated file. DO NOT MODIFY */
package de.ecspride.androidtestapss.easylifecylce;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}