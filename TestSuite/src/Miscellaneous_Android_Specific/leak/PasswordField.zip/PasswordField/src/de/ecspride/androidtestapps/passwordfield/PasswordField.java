package de.ecspride.androidtestapps.passwordfield;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.widget.EditText;

public class PasswordField extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_password_field);
		
		EditText mEdit   = (EditText)findViewById(R.id.pwField);
		Log.v("Password", mEdit.getText().toString());
	}
}
