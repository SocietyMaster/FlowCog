/** Automatically generated file. DO NOT MODIFY */
package de.cased.ecspridetestapps.lognoleak;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}