/** Automatically generated file. DO NOT MODIFY */
package de.ecspride.androidtestapps.staticinitialization;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}