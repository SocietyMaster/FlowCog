/** Automatically generated file. DO NOT MODIFY */
package de.ecspride.androidapps.listenerspecific;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}