/** Automatically generated file. DO NOT MODIFY */
package de.ecspride.androidtestapps.fieldsensitivity1;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}